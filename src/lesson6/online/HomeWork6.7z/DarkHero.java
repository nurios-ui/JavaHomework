package lesson6.online;

public class DarkHero extends SuperHero {

    public DarkHero(String name, int attack, int health, int defence) {
        super(name, attack, health, defence);
    }
}

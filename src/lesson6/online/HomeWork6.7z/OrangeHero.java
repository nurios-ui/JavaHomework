package lesson6.online;

public class OrangeHero extends SuperHero {
    public OrangeHero(String name, int attack, int health, int defence){
        super(name, attack, health, defence);
    }
}
